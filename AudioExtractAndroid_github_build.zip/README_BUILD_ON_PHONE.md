# AudioExtractAndroid – APK ohne Android Studio

Dieses Projekt enthält einen GitHub-Actions-Workflow, der automatisch eine Android-APK baut.

## Auf dem Smartphone

1. Erstelle auf GitHub ein neues Repository.
2. Entpacke dieses ZIP und lade den gesamten Inhalt in das Repository hoch.
3. Öffne im Repository **Actions**.
4. Wähle **Build Android APK**.
5. Tippe auf **Run workflow**.
6. Nach dem erfolgreichen Build findest du unter dem Lauf unter **Artifacts**
   `AudioExtractAndroid-debug-apk`.
7. ZIP herunterladen, entpacken und die enthaltene APK auf dem Smartphone installieren.

Der Workflow baut eine Debug-APK und benötigt kein Android Studio auf dem Smartphone.
