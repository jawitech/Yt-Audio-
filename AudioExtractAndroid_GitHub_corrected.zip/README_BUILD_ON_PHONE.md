# AudioExtractAndroid – GitHub APK Build

Dieses Repository kann die Android-App ohne Android Studio über GitHub Actions bauen.

## Wichtig beim Hochladen

Die Dateien müssen direkt im Repository-Root liegen:

    .github/
    app/
    build.gradle.kts
    gradle.properties
    settings.gradle.kts

Nicht zusätzlich in einem Unterordner `AudioExtractAndroid/`.

## APK bauen

1. Alle Dateien dieses Projekts in ein GitHub-Repository hochladen.
2. In GitHub den Tab **Actions** öffnen.
3. **Build Android APK** auswählen.
4. **Run workflow** drücken.
5. Nach erfolgreichem Build den Artifact
   **AudioExtractAndroid-debug-apk** herunterladen.
6. ZIP entpacken und die APK auf dem Android-Gerät installieren.

Der Workflow richtet Java 17, Android SDK und Gradle automatisch ein.
