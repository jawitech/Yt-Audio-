package de.example.audioextractor

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.mzgs.ffmpegx.FFmpeg
import com.mzgs.ffmpegx.FFmpegOperations
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import android.util.Patterns

private data class RecentAudio(val name: String, val uri: Uri)

class MainActivity : ComponentActivity() {
    private lateinit var ffmpeg: FFmpeg

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ffmpeg = FFmpeg.initialize(this)
        lifecycleScope.launch(Dispatchers.IO) { if (!ffmpeg.isInstalled()) ffmpeg.install() }
        setContent { AudioExtractorApp() }
    }

    private fun displayName(uri: Uri): String = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    } ?: "audio"

    private fun sanitizeBaseName(name: String): String {
        val base = name.substringBeforeLast('.', name).trim().ifBlank { "audio" }
        return base.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
    }

    private fun copyToCache(uri: Uri): File {
        val input = File(cacheDir, "input_${System.currentTimeMillis()}")
        contentResolver.openInputStream(uri).use { src ->
            requireNotNull(src) { "Datei konnte nicht gelesen werden." }
            input.outputStream().use { dst -> src.copyTo(dst) }
        }
        return input
    }

    private suspend fun extract(uri: Uri, bitrate: Int, requestedName: String): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val input = copyToCache(uri)
            val intermediate = File(cacheDir, "audio_${System.currentTimeMillis()}.mp3")
            val finalOutput = File(cacheDir, "${sanitizeBaseName(requestedName)}_${bitrate}k.mp3")
            try {
                val extracted = ffmpeg.operations().extractAudio(
                    inputPath = input.absolutePath,
                    outputPath = intermediate.absolutePath,
                    audioFormat = FFmpegOperations.AudioFormat.MP3
                )
                if (!extracted) error("Audio-Extraktion fehlgeschlagen.")
                val ok = ffmpeg.execute("-y -i ${quote(intermediate.absolutePath)} -vn -c:a libmp3lame -b:a ${bitrate}k ${quote(finalOutput.absolutePath)}")
                if (!ok || !finalOutput.exists()) error("MP3-Erzeugung fehlgeschlagen.")
                saveToDownloads(finalOutput, "${sanitizeBaseName(requestedName)}.mp3")
            } finally {
                input.delete(); intermediate.delete(); finalOutput.delete()
            }
        }
    }

    private fun saveToDownloads(file: File, displayName: String): Uri {
        val resolver: ContentResolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = requireNotNull(resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values))
        try {
            resolver.openOutputStream(uri).use { out ->
                requireNotNull(out)
                file.inputStream().use { it.copyTo(out) }
            }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            return uri
        } catch (t: Throwable) {
            resolver.delete(uri, null, null)
            throw t
        }
    }

    private fun recentDownloads(): List<RecentAudio> {
        val result = mutableListOf<RecentAudio>()
        val projection = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME)
        val selection = "${MediaStore.Downloads.RELATIVE_PATH} = ? AND ${MediaStore.Downloads.MIME_TYPE} = ?"
        val args = arrayOf("${Environment.DIRECTORY_DOWNLOADS}/", "audio/mpeg")
        contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, projection, selection, args, "${MediaStore.Downloads.DATE_ADDED} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
            while (c.moveToNext() && result.size < 8) {
                val uri = Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(id).toString())
                result += RecentAudio(c.getString(name), uri)
            }
        }
        return result
    }

    private fun openFile(uri: Uri) {
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "audio/mpeg")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }

    private fun quote(path: String) = "'" + path.replace("'", "'\\''") + "'"

    @Composable
    private fun AudioExtractorApp() {
        var bitrate by remember { mutableIntStateOf(192) }
        var status by remember { mutableStateOf("Bereit") }
        var busy by remember { mutableStateOf(false) }
        var youtubeUrl by remember { mutableStateOf("") }
        var linkStatus by remember { mutableStateOf("") }
        var sourceName by remember { mutableStateOf("") }
        var recent by remember { mutableStateOf(emptyList<RecentAudio>()) }
        var showQuality by remember { mutableStateOf(false) }

        fun refreshRecent() { recent = recentDownloads() }
        LaunchedEffect(Unit) { refreshRecent() }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@rememberLauncherForActivityResult
            sourceName = displayName(uri)
            busy = true
            status = "Analysiere und konvertiere …"
            lifecycleScope.launch {
                val result = extract(uri, bitrate, sanitizeBaseName(sourceName))
                busy = false
                result.onSuccess { output ->
                    status = "Fertig – ${sanitizeBaseName(sourceName)}.mp3 wurde in Downloads gespeichert."
                    refreshRecent()
                    Toast.makeText(this@MainActivity, "MP3 gespeichert", Toast.LENGTH_SHORT).show()
                }.onFailure { status = "Fehler: ${it.message ?: "Unbekannter Fehler"}" }
            }
        }

        MaterialTheme {
            Scaffold(topBar = {
                TopAppBar(
                    title = { Text("Audio Extractor") },
                    actions = { IconButton(onClick = { refreshRecent() }, enabled = !busy) { Icon(Icons.Default.Refresh, "Aktualisieren") } }
                )
            }) { padding ->
                Column(
                    Modifier.padding(padding).padding(horizontal = 20.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AudioFile, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(14.dp))
                        Column { Text("Video → MP3", style = MaterialTheme.typography.headlineSmall); Text("Schnell, direkt und ohne Speichern-Dialog") }
                    }

                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Quelle", style = MaterialTheme.typography.titleMedium)
                            OutlinedTextField(
                                value = youtubeUrl,
                                onValueChange = { youtubeUrl = it; linkStatus = "" },
                                label = { Text("YouTube-Link (optional)") },
                                placeholder = { Text("https://www.youtube.com/watch?v=…") },
                                leadingIcon = { Icon(Icons.Default.Link, null) },
                                trailingIcon = { if (youtubeUrl.isNotEmpty()) IconButton({ youtubeUrl = "" }) { Icon(Icons.Default.Clear, "Leeren") } },
                                singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth(),
                                supportingText = { if (linkStatus.isNotEmpty()) Text(linkStatus) }
                            )
                            OutlinedButton(
                                onClick = {
                                    val valid = Patterns.WEB_URL.matcher(youtubeUrl.trim()).matches() &&
                                        (youtubeUrl.contains("youtube.com/") || youtubeUrl.contains("youtu.be/"))
                                    linkStatus = if (valid) "YouTube-Link erkannt. Diese Version verarbeitet nur lokal bereitgestellte bzw. zulässigerweise bezogene Medien." else "Bitte einen gültigen YouTube-Link eingeben."
                                },
                                enabled = youtubeUrl.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth()
                            ) { Text("Link prüfen") }
                            Button(onClick = { picker.launch(arrayOf("video/*", "audio/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Datei auswählen")
                            }
                            if (sourceName.isNotBlank()) Text("Ausgewählt: $sourceName", maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("MP3-Qualität", style = MaterialTheme.typography.titleMedium)
                            Box {
                                OutlinedButton(onClick = { showQuality = true }, enabled = !busy) { Text("${bitrate} kbit/s") }
                                DropdownMenu(expanded = showQuality, onDismissRequest = { showQuality = false }) {
                                    listOf(128, 192, 256, 320).forEach { rate ->
                                        DropdownMenuItem(text = { Text("${rate} kbit/s") }, onClick = { bitrate = rate; showQuality = false })
                                    }
                                }
                            }
                            Text("Die Datei wird automatisch in Downloads abgelegt.", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    if (busy) {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)); Text(status) }
                                LinearProgressIndicator(Modifier.fillMaxWidth())
                                Text("Bitte die App während der Konvertierung geöffnet lassen.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    } else if (status != "Bereit") {
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp)); Text(status, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }

                    if (recent.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Zuletzt erstellt", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            TextButton(onClick = { refreshRecent() }) { Text("Aktualisieren") }
                        }
                        recent.forEach { item ->
                            Card(Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(10.dp))
                                    Text(item.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    IconButton(onClick = { openFile(item.uri) }) { Icon(Icons.Default.OpenInNew, "Öffnen") }
                                    IconButton(onClick = { contentResolver.delete(item.uri, null, null); refreshRecent() }) { Icon(Icons.Default.Delete, "Löschen") }
                                }
                            }
                        }
                    }

                    HorizontalDivider()
                    Text("Hinweis", style = MaterialTheme.typography.titleMedium)
                    Text("Die App lädt keine YouTube-Videos herunter und umgeht keine Zugriffsbeschränkungen. Sie wandelt von dir bereitgestellte bzw. zulässigerweise bezogene Medien lokal in MP3 um.", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}
